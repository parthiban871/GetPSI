package com.example.psidemoapp;

import org.junit.Test;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
    @Test
    public void serviceFoundOrNot() throws IOException {
        HttpURLConnection conn;
        conn = null;
        // Given
        String SERVICE_URL = "https://api.data.gov.sg/v1/environment/psi?date_time=2019-11-22T14%3A30%3A00&date=2019-11-22";
        URL url = new URL(SERVICE_URL);
        conn = (HttpURLConnection) url.openConnection();
        assertEquals(200, conn.getResponseCode());
    }
}