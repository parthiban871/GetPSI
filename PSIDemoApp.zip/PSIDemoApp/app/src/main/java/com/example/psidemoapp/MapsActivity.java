package com.example.psidemoapp;

import androidx.fragment.app.FragmentActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        new TestMap().execute();
    }

    class TestMap extends AsyncTask<Void, Void, String> {

        private static final String LOG_TAG = "ExampleApp";
        protected GoogleMap map;
        //private static final String SERVICE_URL = "https://api.myjson.com/bins/4jb09";
        private static final String SERVICE_URL = "https://api.data.gov.sg/v1/environment/psi?date_time=2019-11-22T14%3A30%3A00&date=2019-11-22";
        //"https://api.data.gov.sg/v1/environment/psi?date_time=2019-11-22T14:30:00&date=2019-11-22";

        // Invoked by execute() method of this object
        @Override
        protected String doInBackground(Void... args) {

            HttpURLConnection conn;
            conn = null;
            final StringBuilder json = new StringBuilder();
            try {
                // Connect to the web service
                URL url = new URL(SERVICE_URL);
                conn = (HttpURLConnection) url.openConnection();
                InputStreamReader in = new InputStreamReader(conn.getInputStream());

                // Read the JSON data into the StringBuilder
                int read;
                char[] buff = new char[1024];
                while ((read = in.read(buff)) != -1) {
                    json.append(buff, 0, read);
                }
            } catch (MalformedURLException e) {
                Log.e(LOG_TAG, "MalformedURLException", e);
            } catch (IOException e) {
                Log.e(LOG_TAG, "Error connecting to service", e);
                //throw new IOException("Error connecting to service", e); //uncaught
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }

            return json.toString();
        }

        // Executed after the complete execution of doInBackground() method
        @Override
        protected void onPostExecute(String json) {

            try {

                JSONObject jsondata = new JSONObject(json);
                JSONArray jsonArray = jsondata.getJSONArray("region_metadata");//new JSONArray(json);
                JSONArray readingValue = jsondata.getJSONArray("items");

                for (int i = 0; i < jsonArray.length(); i++) {
                    String test="Readings"+"\r\n";
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    JSONObject jsonObj1 = readingValue.getJSONObject(0);
                    test+="o3_sub_index: "+jsonObj1.getJSONObject("readings").getJSONObject("o3_sub_index").getString(jsonObj.getString("name"))+"\r\n";
                    test+="pm10_twenty_four_hourly: "+jsonObj1.getJSONObject("readings").getJSONObject("pm10_twenty_four_hourly").getString(jsonObj.getString("name"))+"\r\n";
                    test+="pm10_sub_index: "+jsonObj1.getJSONObject("readings").getJSONObject("pm10_sub_index").getString(jsonObj.getString("name"))+"\r\n";
                    test+="co_sub_index: "+jsonObj1.getJSONObject("readings").getJSONObject("co_sub_index").getString(jsonObj.getString("name"))+"\r\n";
                    test+="pm25_twenty_four_hourly: "+jsonObj1.getJSONObject("readings").getJSONObject("pm25_twenty_four_hourly").getString(jsonObj.getString("name"))+"\r\n";
                    test+="so2_sub_index: "+jsonObj1.getJSONObject("readings").getJSONObject("so2_sub_index").getString(jsonObj.getString("name"))+"\r\n";
                    test+="co_eight_hour_max: "+jsonObj1.getJSONObject("readings").getJSONObject("co_eight_hour_max").getString(jsonObj.getString("name"))+"\r\n";
                    test+="no2_one_hour_max: "+jsonObj1.getJSONObject("readings").getJSONObject("no2_one_hour_max").getString(jsonObj.getString("name"))+"\r\n";
                    test+="so2_twenty_four_hourly: "+jsonObj1.getJSONObject("readings").getJSONObject("so2_twenty_four_hourly").getString(jsonObj.getString("name"))+"\r\n";
                    test+="pm25_sub_index: "+jsonObj1.getJSONObject("readings").getJSONObject("pm25_sub_index").getString(jsonObj.getString("name"))+"\r\n";
                    test+="psi_twenty_four_hourly: "+jsonObj1.getJSONObject("readings").getJSONObject("psi_twenty_four_hourly").getString(jsonObj.getString("name"))+"\r\n";
                    test+="o3_eight_hour_max: "+jsonObj1.getJSONObject("readings").getJSONObject("o3_eight_hour_max").getString(jsonObj.getString("name"))+"\r\n";

                    String vname = jsonObj.getString("name");
                    if(!vname.equals("central")) {

                        LatLng latLng = new LatLng(jsonObj.getJSONObject("label_location").getDouble("latitude"),
                                jsonObj.getJSONObject("label_location").getDouble("longitude"));


                        if (i == 0) {
                            CameraPosition cameraPosition = new CameraPosition.Builder()
                                    .target(latLng).zoom(10).build();

                            mMap.animateCamera(CameraUpdateFactory
                                    .newCameraPosition(cameraPosition));
                        }


                        // Setting a custom info window adapter for the google map
                        MarkerInfoWindowAdapter markerInfoWindowAdapter = new MarkerInfoWindowAdapter(getApplicationContext());
                        MyMarkerClickListener myMarkerClickListener = new MyMarkerClickListener();
                        mMap.setInfoWindowAdapter(markerInfoWindowAdapter);
                        mMap.setOnMarkerClickListener(myMarkerClickListener);
                        // Adding and showing marker when the map is touched
                        final String finalTest = test;
                        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                            @Override
                            public void onMapClick(LatLng arg0) {
                              //  mMap.clear();
                                MarkerOptions markerOptions = new MarkerOptions();
                                markerOptions.position(arg0);
                                markerOptions.snippet(finalTest);
                                mMap.animateCamera(CameraUpdateFactory.newLatLng(arg0));
                               // Marker marker = mMap.addMarker(markerOptions);
                              //  marker.hideInfoWindow();
                            }
                        });


                        // Create a marker for each city in the JSON data.
                        mMap.addMarker(new MarkerOptions()
                                .title(test).snippet(test)
                                .position(latLng));
                        test = "";
                    }
                }
            } catch (JSONException e) {
                Log.e(LOG_TAG, "Error processing JSON", e);
            }

        }


    }
}
